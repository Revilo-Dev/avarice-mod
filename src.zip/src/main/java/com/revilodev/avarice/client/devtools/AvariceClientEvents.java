package com.revilodev.avarice.client.devtools;

import com.revilodev.avarice.Avarice;
import com.revilodev.avarice.client.ui.AvariceUiScreen;
import com.revilodev.avarice.client.ui.ClientScreenAccess;
import com.revilodev.avarice.core.config.UiConfigService;
import com.revilodev.avarice.core.reload.ConfigFileWatcher;
import com.revilodev.avarice.devtools.values.ValueService;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.lifecycle.ClientStartedEvent;
import net.neoforged.neoforge.client.event.lifecycle.ClientStoppingEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/** Client-only registration keeps all Minecraft client and UI Lib types away from dedicated servers. */
@EventBusSubscriber(modid = Avarice.MODID, value = Dist.CLIENT)
public final class AvariceClientEvents {
    private static ConfigFileWatcher watcher;
    static final KeyMapping.Category CATEGORY = new KeyMapping.Category(Identifier.fromNamespaceAndPath(Avarice.MODID, "development"));
    static final KeyMapping INSPECT = new KeyMapping("key.avarice.inspect", InputConstants.KEY_F8, CATEGORY);
    static final KeyMapping RELOAD_UI = new KeyMapping("key.avarice.reload_ui", InputConstants.KEY_F9, CATEGORY);
    private AvariceClientEvents() { }
    @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent event) { event.registerCategory(CATEGORY); event.register(INSPECT); event.register(RELOAD_UI); }
    @SubscribeEvent public static void tick(ClientTickEvent.Post event) {
        if (!developmentEnabled()) return;
        Minecraft minecraft = Minecraft.getInstance();
        while (INSPECT.consumeClick()) if (ClientScreenAccess.current() instanceof AvariceUiScreen screen) screen.toggleInspector();
        while (RELOAD_UI.consumeClick()) { UiConfigService.ReloadResult result = UiConfigService.reload(); if (ClientScreenAccess.current() instanceof AvariceUiScreen screen) screen.reloadUi(); else notify(result.message()); }
    }
    @SubscribeEvent public static void registerCommand(RegisterClientCommandsEvent event) {
        if (!developmentEnabled()) return;
        event.getDispatcher().register(Commands.literal("avarice").then(Commands.literal("dev").then(Commands.literal("ui").executes(context -> { ClientScreenAccess.open(new AvariceUiScreen()); return 1; })).then(Commands.literal("values").executes(context -> { boolean success = ValueService.reload(); notify(success ? "Values reloaded" : "Values reload failed"); return success ? 1 : 0; }))));
    }
    @SubscribeEvent public static void startWatcher(ClientStartedEvent event) {
        if (!developmentEnabled() || watcher != null) return;
        try { watcher = new ConfigFileWatcher(UiConfigService.FILE.getParent(), event.getClient()::execute, AvariceClientEvents::reloadOpenScreen); }
        catch (java.io.IOException exception) { Avarice.LOGGER.warn("Avarice automatic configuration reload is unavailable", exception); }
    }
    @SubscribeEvent public static void stopWatcher(ClientStoppingEvent event) {
        if (watcher == null) return;
        try { watcher.close(); } catch (java.io.IOException exception) { Avarice.LOGGER.warn("Could not close Avarice configuration watcher", exception); } finally { watcher = null; }
    }
    private static void reloadOpenScreen() { UiConfigService.ReloadResult result = UiConfigService.reload(); if (ClientScreenAccess.current() instanceof AvariceUiScreen screen) screen.reloadUi(); else notify(result.message()); }
    private static boolean developmentEnabled() { return Boolean.getBoolean("avarice.devtools"); }
    private static void notify(String message) { Avarice.LOGGER.info("[Avarice] {}", message); }
}
