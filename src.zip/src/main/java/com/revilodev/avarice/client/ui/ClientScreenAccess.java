package com.revilodev.avarice.client.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/** Isolates transient Minecraft screen mappings from Avarice's UI code. */
public final class ClientScreenAccess {
    private ClientScreenAccess() { }
    public static void open(Screen screen) { invoke("setScreen", new Class<?>[] {Screen.class}, screen); }
    public static Screen current() { try { var field = Minecraft.class.getField("screen"); return (Screen) field.get(Minecraft.getInstance()); } catch (ReflectiveOperationException exception) { return null; } }
    private static void invoke(String name, Class<?>[] parameters, Object value) { try { Minecraft.class.getMethod(name, parameters).invoke(Minecraft.getInstance(), value); } catch (ReflectiveOperationException exception) { throw new IllegalStateException("Minecraft screen API is unavailable", exception); } }
}
