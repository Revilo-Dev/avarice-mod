package com.revilodev.avarice.client.ui;

import com.revilodev.avarice.client.ui.layout.LayoutResolver;
import com.revilodev.avarice.core.config.UiConfig;
import com.revilodev.avarice.core.config.UiConfigService;
import com.daqem.uilib.gui.AbstractScreen;
import com.daqem.uilib.gui.component.color.ColorComponent;
import com.daqem.uilib.gui.component.text.TextComponent;
import com.daqem.uilib.gui.widget.ButtonWidget;
import net.minecraft.network.chat.Component;

/** UI Lib-backed development screen. Avarice owns layout/theming; UI Lib owns component rendering/input. */
public final class AvariceUiScreen extends AbstractScreen {
    private boolean inspectorEnabled;
    private String status = "F8 inspector · F9 reload";
    public AvariceUiScreen() { super(Component.literal("Avarice Development UI")); }
    @Override protected void init() { rebuild(); }
    public void rebuild() {
        clear();
        UiConfig config = UiConfigService.current();
        UiConfig.ScreenDefinition screen = config.screens().get("development_demo");
        if (screen == null) return;
        LayoutResolver.Bounds viewport = new LayoutResolver.Bounds(0, 0, width, height);
        var bounds = new LayoutResolver().resolve(screen, viewport).get("demo_panel");
        UiConfig.Style style = config.theme().styles().get(screen.elements().get("demo_panel").style());
        int panelColor = style != null && style.background() != null ? style.background() : config.theme().colors().get("surface");
        addComponent(new ColorComponent((int) bounds.x(), (int) bounds.y(), (int) bounds.width(), (int) bounds.height(), panelColor));
        addComponent(new TextComponent((int) bounds.x() + 12, (int) bounds.y() + 12, Component.literal("Avarice · Development Foundation"), config.theme().colors().get("text")));
        addComponent(new TextComponent((int) bounds.x() + 12, (int) bounds.y() + 34, Component.literal(status), config.theme().colors().get("primary")));
        ButtonWidget reload = new ButtonWidget((int) bounds.x() + 12, (int) bounds.y() + 60, 112, 20, Component.literal("Reload UI"), button -> reloadUi());
        ButtonWidget close = new ButtonWidget((int) bounds.x() + 136, (int) bounds.y() + 60, 112, 20, Component.literal("Close"), button -> ClientScreenAccess.open(null));
        addWidget(reload); addWidget(close);
    }
    public void toggleInspector() { inspectorEnabled = !inspectorEnabled; status = inspectorEnabled ? "Inspector enabled (F8)" : "Inspector disabled (F8)"; rebuild(); }
    public void reloadUi() { UiConfigService.ReloadResult result = UiConfigService.reload(); status = result.success() ? result.message() : "Reload failed: " + result.message(); rebuild(); }
}
