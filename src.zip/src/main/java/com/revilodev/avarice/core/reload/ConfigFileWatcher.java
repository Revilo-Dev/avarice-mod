package com.revilodev.avarice.core.reload;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

/** Debounced WatchService wrapper; callers schedule game-thread work themselves. */
public final class ConfigFileWatcher implements AutoCloseable {
    private final WatchService watcher;
    private final AtomicBoolean running = new AtomicBoolean();
    private Thread thread;
    public ConfigFileWatcher(Path directory, Executor callbackExecutor, Runnable changed) throws IOException {
        watcher = FileSystems.getDefault().newWatchService(); directory.register(watcher, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE);
        thread = Thread.ofVirtual().name("avarice-config-watcher").start(() -> watch(callbackExecutor, changed)); running.set(true);
    }
    private void watch(Executor callbackExecutor, Runnable changed) { long last = 0; while (running.get()) try { WatchKey key = watcher.take(); boolean relevant = key.pollEvents().stream().anyMatch(event -> event.context().toString().endsWith(".json")); key.reset(); long now = System.nanoTime(); if (relevant && now - last > 250_000_000L) { last = now; callbackExecutor.execute(changed); } } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; } catch (Exception ignored) { break; } }
    @Override public void close() throws IOException { running.set(false); if (thread != null) thread.interrupt(); watcher.close(); }
}
